# Login Notification Plugin
## Description

This is a sample plugin that will send an email notification to the site admin every time someone logs into your Wordpress site.

## Installation
 This plugin will send an email notification to the admin every time a user logs in. It will also send an email to the user who just logged in, if they have an email address associated with their account. 

 You SHOULD customize the email message, recipient, and subject as needed. 

 To use this plugin, save the code to a file named  login-notification.php  and place it in the  wp-content/plugins  directory of your WordPress installation. Then activate the plugin from the WordPress admin dashboard. 

 Note: Make sure to replace  *admin-email-address@test.com*  with the actual email address where you want to receive the notifications.

 This is a simple example, and you can further customize it to suit your needs. 
 