<?php
// Silence is golden.


// We don't need to do anything here. 

// We need to put an index.php file in the plugin's directory to prevent users from accessing the plugin's directory or files directly.
